﻿using System.Drawing;
using System.Numerics;
using System.Xml.Linq;
using Raylib_CsLo;
using static System.Formats.Asn1.AsnWriter;
using static System.Net.Mime.MediaTypeNames;
using static Snake_game.Cell;

namespace Snake_game
{
    // Määrittelee pelikentän ruudukon
    internal class Grid
    {
        private struct Position
        {
            public int y;
            public int x;
        };
        
        public enum SnakeMoveResult
        {
            Ok,     // Liikkuminen onnistui
            Nok,    // Liikkuminen epäonnistui
            Win     // Pelaaja on voittanut
        }

        private int ySize;
        private int xSize;
        
        // Ruudukko, joka tallentaa solut ja niiden tilat
        private Cell[,] grid;

        private Position applePosition;
        private Position headPosition;
        private Position tailPosition;
        private int snakeLength;

        private Random rnd;
        private int cellSizeInPixels;

        Texture appleTexture;
        Texture headTexture;
        Texture bodyTexture;
        Texture tailTexture;
        
        // Tekee ruudut tyhjäksi
        public Grid(int ySize, int xSize, int cellSizeInPixels)
        {
            this.ySize = ySize;
            this.xSize = xSize;
            grid = new Cell[ySize, xSize];
            for (int y = 0; y < ySize; y++)
            {
                for (int x = 0; x < xSize; x++)
                {
                    this.grid[y, x] = new Cell(Cell.Identifier.Empty, Cell.Direction.None);
                }
            }
            rnd = new Random();
            this.cellSizeInPixels = cellSizeInPixels;
        }
        
        // Palauttaa pelin alkutilanteeseen
        public void Reset()
        {
            for (int y = 0; y < ySize; y++)
            {
                for (int x = 0; x < xSize; x++)
                {
                    this.grid[y, x].UpdateCell(Cell.Identifier.Empty, Cell.Direction.None);
                }
            }
            this.ResetSnakePosition();
            this.ResetApplePosition();
        }

        // Asettaa käärmeen satunnaiseen paikkaan
        private void ResetSnakePosition()
        {
            int y = rnd.Next(1, this.ySize - 1);
            int x = rnd.Next(1, this.xSize - 1);
            this.headPosition.y = y;
            this.headPosition.x = x;
            this.tailPosition.y = y;
            this.tailPosition.x = x;
            this.snakeLength = 1;
            this.grid[y, x].UpdateCell(Cell.Identifier.Head, Cell.Direction.Up);
        }

        // Asettaa omenan satunnaiseen paikkaan
        private void ResetApplePosition()
        {
            Position[] emptyCells = new Position[this.ySize * this.xSize];
            int numEmptyCells = 0;
            int y;
            int x;

            // Etsii kaikki tyhjät ruudut ruudukosta
            for (y = 0; y < ySize; y++)
            {
                for (x = 0; x < xSize; x++)
                {
                    if (this.grid[y, x].identifier == Cell.Identifier.Empty)
                    {
                        emptyCells[numEmptyCells].y = y;
                        emptyCells[numEmptyCells].x = x;
                        numEmptyCells++;
                    }
                }
            }

            // Valitsee satunnaisen tyhjän solun omenan sijainniksi
            int index = rnd.Next(0, numEmptyCells);
            y = emptyCells[index].y;
            x = emptyCells[index].x;
            this.applePosition.y = y;
            this.applePosition.x = x;
            this.grid[y, x].UpdateCell(Cell.Identifier.Apple, Cell.Direction.None);
        }

        // Lataa tekstuurit kuville
        public void ReadTexturesAfterInitWindow()
        {
            this.appleTexture = Raylib.LoadTexture("textures/apple.png");
            this.headTexture = Raylib.LoadTexture("textures/head.png");
            this.bodyTexture = Raylib.LoadTexture("textures/body.png");
            this.tailTexture = Raylib.LoadTexture("textures/tail.png");
        }

        // Päivittää käärmeen suunnan
        public void UpdateSnakeDirection(Cell.Direction direction)
        {
            int y = this.headPosition.y;
            int x = this.headPosition.x;
            (int newY, int newX) = CalculateNewCoordinate(y, x, direction);

            bool isNewCoordinateValid = CanSnakeMoveToNewCoordinate(newY, newX);
            if (isNewCoordinateValid)
            {
                this.grid[y, x].UpdateCell(Cell.Identifier.Head, direction);
            }
        }

        // Laskee uuden koordinaatin
        private (int newY, int newX) CalculateNewCoordinate(int y, int x, Cell.Direction direction)
        {
            int newY = y;
            int newX = x;
            if (direction == Cell.Direction.Up)
            {
                newY = y - 1;
            }
            else if (direction == Cell.Direction.Down)
            {
                newY = y + 1;
            }
            else if (direction == Cell.Direction.Left)
            {
                newX = x - 1;
            }
            else if (direction == Cell.Direction.Right)
            {
                newX = x + 1;
            }

            return (newY, newX);
        }

        // Voiko käärme liikkua uuteen koordinaattiin
        private bool CanSnakeMoveToNewCoordinate(int newY, int newX)
        {
            bool isNewCoordinateValid = false;
            if (newY >= 0 && newY < ySize && newX >= 0 && newX < xSize)
            {
                if (this.grid[newY, newX].identifier == Cell.Identifier.Empty ||
                    this.grid[newY, newX].identifier == Cell.Identifier.Apple)
                {
                    isNewCoordinateValid = true;
                }
            }
            return isNewCoordinateValid;
        }

        // Liikuttaa käärmettä ja tarkistaa tuloksen
        public SnakeMoveResult MoveSnake()
        {
            int y = this.headPosition.y;
            int x = this.headPosition.x;
            (int newY, int newX) = CalculateNewCoordinate(y, x, this.grid[y, x].direction);

            bool isNewCoordinateValid = CanSnakeMoveToNewCoordinate(newY, newX);
            if (this.snakeLength == ySize * xSize - 1)
            {
                return SnakeMoveResult.Win;
            }
            else if (isNewCoordinateValid == false)
            {
                return SnakeMoveResult.Nok;
            }
            else
            {
                if (this.grid[newY, newX].identifier == Cell.Identifier.Apple)
                {
                    GrowSnakeSize(newY, newX);
                    ResetApplePosition();
                }
                else if (this.grid[newY, newX].identifier == Cell.Identifier.Empty)
                {
                    UpdateSnakePosition();
                }
                return SnakeMoveResult.Ok;
            }
        }

        // Kasvattaa käärmeen kokoa
        private void GrowSnakeSize(int newY, int newX)
        {
            int y = this.headPosition.y;
            int x = this.headPosition.x;
            if (this.snakeLength == 1)
            {
                this.grid[y, x].UpdateCellIdentifier(Cell.Identifier.Tail);
                this.tailPosition.y = y;
                this.tailPosition.x = x;
            }
            else
            {
                this.grid[y, x].UpdateCellIdentifier(Cell.Identifier.Body);
            }
            this.snakeLength++;
            this.grid[newY, newX].UpdateCell(Cell.Identifier.Head, this.grid[y, x].direction);
            this.headPosition.y = newY;
            this.headPosition.x = newX;
        }

        // Päivittää käärmeen sijainnin
        private void UpdateSnakePosition()
        {
            int y = this.tailPosition.y;
            int x = this.tailPosition.x;
            (int newY, int newX) = CalculateNewCoordinate(y, x, this.grid[y, x].direction);

            if (this.snakeLength == 1)
            {
                this.grid[newY, newX].UpdateCell(Cell.Identifier.Head, this.grid[y, x].direction);
                this.tailPosition.y = newY;
                this.tailPosition.x = newX;
                this.headPosition.y = newY;
                this.headPosition.x = newX;
                this.grid[y, x].UpdateCell(Cell.Identifier.Empty, Cell.Direction.None);
            }
            else
            {
                this.grid[y, x].UpdateCell(Cell.Identifier.Empty, Cell.Direction.None);
                this.tailPosition.y = newY;
                this.tailPosition.x = newX;
                this.grid[newY, newX].UpdateCell(Cell.Identifier.Tail, this.grid[newY, newX].direction);

                y = this.headPosition.y;
                x = this.headPosition.x;
                this.grid[y, x].UpdateCellIdentifier(Cell.Identifier.Body);
                this.grid[newY, newX].UpdateCell(Cell.Identifier.Head, this.grid[y, x].direction);
            }
        }

        // Piirtää peliruudukon
        public void Draw()
        {
            for (int y = 0; y < ySize; y++)
            {
                for (int x = 0; x < xSize; x++)
                {
                    DrawGridCell(y, x);
                }
            }
        }

        // Piirtää tietyn Ruudukon
        private void DrawGridCell(int y, int x)
        {
            Rectangle rectangle = new Rectangle(x * cellSizeInPixels, y * cellSizeInPixels, cellSizeInPixels, cellSizeInPixels);
            Texture texture = grid[y, x].identifier switch
            {
                Cell.Identifier.Apple => appleTexture,
                Cell.Identifier.Head => headTexture,
                Cell.Identifier.Body => bodyTexture,
                Cell.Identifier.Tail => tailTexture,
                _ => default
            };
            Raylib.DrawTexture(texture, (int)rectangle.x, (int)rectangle.y, Color.WHITE);
        }
    }
}
