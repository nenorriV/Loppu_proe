﻿using System.Numerics;

namespace Snake_game
{
    // Määrittelee pelikentän solun
    internal class Cell
    {
        public enum Identifier
        {
            Empty,
            Apple,
            Head,
            Body,
            Tail
        }
        public enum Direction
        {
            None,  
            Up,
            Down,
            Left,
            Right
        }

        public Identifier identifier;
        public Direction direction; 

        // solun tyyppi ja suunta
        public Cell(Identifier identifier, Direction direction)
        {
            this.identifier = identifier;
            this.direction = direction;
        }
        
        // Päivittää solun tyypin ja suunnan
        public void UpdateCell(Identifier identifier, Direction direction)
        {
            this.identifier = identifier;
            this.direction = direction;
        }
        
        // Päivittää ainoastaan solun tyypin
        public void UpdateCellIdentifier(Identifier identifier)
        {
            this.identifier = identifier;
        }
    }
}
