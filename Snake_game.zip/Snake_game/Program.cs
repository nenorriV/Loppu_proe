﻿namespace Snake_game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Snake game = new Snake();
            game.Run();
        }
    }
}