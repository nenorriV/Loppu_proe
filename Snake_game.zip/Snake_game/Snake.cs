﻿using Raylib_CsLo;
using System.Numerics;

namespace Snake_game
{
    internal class Snake
    {
        // Peliruudukon koko
        static int gridSizeY = 10;
        static int gridSizeX = 15;
        
        static int cellSizeInPixels = 40;

        Grid grid = new Grid(gridSizeY, gridSizeX, cellSizeInPixels);

        // Ikkunan korkeus ja leveys pikseleinä
        int window_height = gridSizeY * cellSizeInPixels;
        int window_width = gridSizeX * cellSizeInPixels;

        // Käärmeen liikkumisväliaika
        double moveTimeInterval = 0.5f;
        double lastMoveTime = 0.0f;

        // Pelin eri tilat
        enum GameState
        {
            Start,
            Play,
            Score
        }
        GameState state;
        Grid.SnakeMoveResult gameResult;

        // Suorittaa pelin
        public void Run()
        {
            Init();
            GameLoop();
        }

        // Käynistää pelin alusta
        void Init()
        {
            grid.Reset();
            state = GameState.Start;

            Raylib.InitWindow(window_width, window_height, "Snake");
            Raylib.SetTargetFPS(30);

            grid.ReadTexturesAfterInitWindow();
        }

        // Pelisilmukka
        void GameLoop()
        {
            while (Raylib.WindowShouldClose() == false)
            {
                switch (state)
                {
                    case GameState.Start:
                        ProcessStartState();
                        DrawStartState();
                        break;
                    case GameState.Play:
                        ProcessPlayState();
                        DrawPlayState();
                        break;
                    case GameState.Score:
                        ProcessScoreState();
                        DrawScoreState();
                        break;
                }
            }
        }

        // Hoitaa aloitustilan tapahtumat
        void ProcessStartState()
        {
            Cell.Direction direction = ReadDirectionFromKeyboard();
            if (direction != Cell.Direction.None)
            {
                grid.UpdateSnakeDirection(direction);
                this.lastMoveTime = Raylib.GetTime();
                state = GameState.Play;
            }
        }

        // Piirtää aloitustilan
        void DrawStartState()
        {
            Raylib.BeginDrawing();
            Raylib.ClearBackground(Raylib.BLACK);

            grid.Draw();

            int fontSize = 20;
            string instructionText = "To control snake use UP, DOWN, LEFT and RIGHT arrows";
            int instructionWidth = Raylib.MeasureText(instructionText, fontSize);
            (int appleY, int appleX) = grid.GetApplePosition();
            (int headY, int headX) = grid.GetSnakeHeadPosition();

            int y = 1;
            for (; y < gridSizeY; y++)
            {
                if (y != appleY && y != headY)
                {
                    Raylib.DrawText(instructionText, window_width / 2 - instructionWidth / 2,
                        y * cellSizeInPixels + (cellSizeInPixels / 2), fontSize, Raylib.WHITE);
                    y++;
                    break;
                }
            }

            Raylib.EndDrawing();
        }

        // Hoitaa pelitilan tapahtumat
        void ProcessPlayState()
        {
            Cell.Direction direction = ReadDirectionFromKeyboard();
            if (direction != Cell.Direction.None)
            {
                grid.UpdateSnakeDirection(direction);
            }

            double timeNow = Raylib.GetTime();
            if (timeNow - lastMoveTime >= moveTimeInterval)
            {
                lastMoveTime = timeNow;
                Grid.SnakeMoveResult moveResult = grid.MoveSnake();
                if (moveResult == Grid.SnakeMoveResult.Nok || moveResult == Grid.SnakeMoveResult.Win)
                {
                    state = GameState.Score;
                    gameResult = moveResult;
                }
            }
        }

        // Piirtää pelin
        void DrawPlayState()
        {
            Raylib.BeginDrawing();
            Raylib.ClearBackground(Raylib.DARKBLUE);

            grid.Draw();

            Raylib.EndDrawing();
        }

        // Käsittelee pisteet
        void ProcessScoreState()
        {
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_ENTER))
            {
                grid.Reset();
                state = GameState.Start;
            }
        }

        // Pisteet
        void DrawScoreState()
        {
            Raylib.BeginDrawing();
            Raylib.ClearBackground(Raylib.DARKGRAY);

            grid.Draw();

            int score = grid.GetSnakeLength();
            int fontSize = 20;
            string scoreText;
            if (gameResult == Grid.SnakeMoveResult.Win)
            {
                scoreText = $"You Win! Final score {score}";
            }
            else
            {
                scoreText = $"You Loose! Final score {score}";
            }
            string instructionText = "Game over. Press Enter to play again";
            int scoreWidth = Raylib.MeasureText(scoreText, fontSize);
            int instructionWidth = Raylib.MeasureText(instructionText, fontSize);

            Raylib.DrawText(scoreText, window_width / 2 - scoreWidth / 2,
                window_height / 2 - 60, fontSize, Raylib.WHITE);
            Raylib.DrawText(instructionText, window_width / 2 - instructionWidth / 2,
                window_height / 2, fontSize, Raylib.WHITE);

            Raylib.EndDrawing();
        }

        // Nnäppäimistö
        Cell.Direction ReadDirectionFromKeyboard()
        {
            Cell.Direction direction = Cell.Direction.None;
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_UP))
            {
                direction = Cell.Direction.Up;
            }
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_DOWN))
            {
                direction = Cell.Direction.Down;
            }
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_LEFT))
            {
                direction = Cell.Direction.Left;
            }
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_RIGHT))
            {
                direction = Cell.Direction.Right;
            }
            return direction;
        }
    }
}
